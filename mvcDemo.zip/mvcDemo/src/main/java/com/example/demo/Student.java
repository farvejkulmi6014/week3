package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Student {
	public void userName() {
		System.out.println("demo text");
	}
}
