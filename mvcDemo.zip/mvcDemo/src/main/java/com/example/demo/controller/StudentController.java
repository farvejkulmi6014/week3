package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class StudentController {

	@Autowired
	EmpService service;

	@RequestMapping("/")
	public ModelAndView dem(ModelAndView mv)
	{
		mv.setViewName("index.jsp");

		return mv;
	}
	
	
	@RequestMapping("/print")
	/*public String demo(HttpServletRequest req)
	{
		HttpSession session=req.getSession();
		String name=req.getParameter("name");
		String designation=req.getParameter("desig");

		System.out.println("hi" + name +" ur designation is "+ designation);
		session.setAttribute("username", name);
		return "index.jsp";
	}*/

	public ModelAndView demo(@RequestParam("name") String name, ModelAndView mv){
		mv.setViewName("welcome.jsp");
		mv.addObject("welcome.jsp", name);
		return mv;
	}

	@RequestMapping("/save")
	public ModelAndView empSave(ModelAndView mv, Employee emp ) {
		mv.setViewName("welcome.jsp");
		/*	mv.addObject("emp", emp);*/
		List<Employee> list = service.getEmployees();
		mv.addObject("all", list);
		service.saveEmp(emp);
		return mv;
	}

	/*@RequestMapping(method = RequestMethod.DELETE, value = "")
	public ModelAndView delet(@PathVariable int id){
		return service.getEmployees();
	}*/
	
}
